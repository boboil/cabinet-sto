<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontController extends Controller
{
    const SITE = 'http://95.217.38.198/csws/';
    private $access_token = '';
    private $authorization = [];
    public function __construct()
    {
        $url = $this::SITE.'authorize';
        $data = [
            'username' => '03516g',
            'password' => '1234567890',
            'grant_type' => 'password'
        ];
        $pr =  $this->send_request_post_auth($url, $data);
        $this->access_token = json_decode($pr)->access_token;
        $this->authorization = [
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type:application/json'
        ];
    }

    public function index()
    {
       $url = $this::SITE.'cs/user';
       $pr =  $this->send_request_get($url);
       dd($pr);


    }
    public function history()
    {
        $url = $this::SITE.'cs/history';
        $orders =  $this->send_request_get($url);
        return view('user', compact('orders'));
    }

    private function send_request_post($link, $params)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
        curl_setopt($ch,CURLOPT_HTTPHEADER, $this->authorization);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $response = curl_exec($ch);

        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $body = substr($response, $header_size);
        curl_close($ch);
        return $body;
    }
    private function send_request_post_auth($link, $params)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $response = curl_exec($ch);

        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $body = substr($response, $header_size);
        curl_close($ch);
        return $body;
    }
    private function send_request_get($url)
    {
        $curl = curl_init();
        curl_setopt($curl,CURLOPT_URL, $url);
        curl_setopt($curl,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl,CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, TRUE);
        curl_setopt($curl,CURLOPT_HTTPHEADER, $this->authorization);
        $out = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $body = substr($out, $header_size);
        curl_close($curl);
        return json_decode($body);
    }

}
