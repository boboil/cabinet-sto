/* ------------------------------------------------------------------------------
 *  # CarStore WebModule
 * ---------------------------------------------------------------------------- */


// Setup module
// ------------------------------

var csws = function() {

    // Setting defaults for forms
    var svcUrl = "api/";
    var svcAuthorization = "AuthCS";//"Authorization";
    var searchUrl = "catalog.html"

    //  --  CACHE ----------------
    var _moduleCache = function () {

        var emptyList = { ts: 0, list: [] };
        var cToken;

        function funcGetToken() {
            return cToken;
        }

        function funcGetRequestToken() {
            return "bearer " + cToken;
        }

        function funcUpdateToken(data) {
            cToken = data;
            localStorage.setItem("accesstoken", cToken);
        }

        function funcRemoveToken(data) {
            cToken = undefined;
            localStorage.removeItem("accesstoken");
        }

        function funcGetCachedData(value, edata) {
            return (localStorage.getItem(value) !== null) ? JSON.parse(localStorage.getItem(value)) : ((edata != undefined) ? edata : emptyList);
        }

        function funcUpdateCachedData(value, data) {
            data.ts = Date.now();
            localStorage.setItem(value, JSON.stringify(data));
        }

        function funcIsDataUpToDate(data, interval) {
            return ((Date.now() - data.ts) < ((interval != undefined) ? interval : 21600000)); // 6 hours
        }

        function funcInitialization() {
            cToken = localStorage.accesstoken;
        }

        return {
            Init: function () { funcInitialization() },
            Token: function () { return funcGetToken() },
            ReqToken: function () { return funcGetRequestToken() },
            RemoveToken: function () { funcRemoveToken() },
            UpdateToken: function (data) { funcUpdateToken(data) },
            CachedData: function (value, edata) { return funcGetCachedData(value, edata) },
            IsDataUpToDate: function (data, interval) { return funcIsDataUpToDate(data, interval) },
            UpdateCachedData: function (value, data) { funcUpdateCachedData(value, data) },
        }
    }();

    //  --  USER ----------------
    var _moduleUser = function () {

        var userData;

        function funcIsUserLogedIn() {
            return (userData !== null);
        }

        function funcGetUserData() {
            return userData;
        }

        function funcUserShowInfo(data, showlogin) {
            userData = data;
            $("#mUser").addClass((userData === null) ? "sr-only" : "");
            $("#mUser").removeClass((userData !== null) ? "sr-only" : "");
            $("#mLogin").addClass((userData !== null) ? "sr-only" : "");
            $("#mLogin").removeClass((userData === null) ? "sr-only" : "");
            $("#lUserName").text((userData !== null) ? userData.Name : "");
            $("#lUserBalance").text((userData !== null) ? userData.Balance : "");
            $("#lBalance").text((userData !== null) ? userData.Balance : "");
            $("#iRequestName").val((userData !== null) ? userData.Name : "");
            $("#iRequestPhone").val((userData !== null) ? userData.Phone : "");
            $("#iRequestEmail").val((userData !== null) ? userData.Email : "");
            if (showlogin) $("#nLogin").dropdown("toggle");
        }

        function funcUserInfoLoad() {
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/user",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    funcUserShowInfo(data, false);
                    csws.Basket().LoadUserInfo(data);
                },
                error: function (data) {
                    funcUserShowInfo(null, false);
                }
            });
        }

        function funcUserAuthorization(event) {
            if (event !== undefined) event.preventDefault();
            var formData = $("#fLogin").serialize();
            $.ajax({
                type: "POST",
                url: svcUrl + "authorize",
                dataType: "json",
                data: formData,
                success: function (data) {
                    csws.Cache().UpdateToken(data.access_token);
                    funcUserInfoLoad();
                    csws.Basket().ReloadBacketPrices();
                    if (csws.OrderHistory().IsPageLoaded()) csws.OrderHistory().Load();
                    if (csws.Registration().IsPageLoaded()) window.location.replace("/cabinet.php");

                },
                error: function (data) {
                    if (data.status === 401) return $("#lLofinStatus").text("Неверное имя пользователя или пароль");
                    else funcShowErrorMessage($("#lLofinStatus"), data);
                    funcLogErrors("funcUserAuthorization", data);
                }
            });
        }

        function funcUserLogout(event) {
            if (event !== undefined) event.preventDefault();
            csws.Cache().RemoveToken();
            window.location.replace("/");
        }

        function funcUserPassworsRecovery(event) {
            if (event !== undefined) event.preventDefault();
            funcPageUpdateProgressInfo(1, null, null, "#isPassRecovery", "", null);

            var formData = $("#fPassRecovery").serialize();
            $.ajax({
                type: "POST",
                url: svcUrl + "cs/resetpassword",
                dataType: "json",
                data: formData,
                success: function (data) {
                    funcPageUpdateProgressInfo(2, null, null, "#isPassRecovery", "Пароль отправлен на ваш адрес электронной почты", null);
                    $("#modalPassRecover").modal("hide");
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, null, null, "#isPassRecovery", null, data);
                    funcLogErrors("funcUserPassworsRecovery", data);
                }
            });
        }

        function funcInitialization() {
            funcUserInfoLoad();
        }

        return {
            Init: function () { funcInitialization() },
            UserData: function () { return funcGetUserData(); },
            IsLogedIn: function () { return funcIsUserLogedIn(); },
            Login: function (event) { funcUserAuthorization(event); },
            Logout: function (event) { funcUserLogout(event); return false; },
            ShowInfo: function (data, showlogin) { funcUserShowInfo(data, showlogin); },
            PasswordRecovery: function (event) { funcUserPassworsRecovery(event); },
        }
    }();

    //  --  BASKET ----------------
    var _moduleBasket = function () {

        var orderData;
        var productsData = [];

        function funcRenderBasket() {
            $("#aBasket").empty();
            $("#aBasket").append(funcRenderBasketProducts(searchUrl, orderData.Products));
            $("#lBasketCount").text((orderData.Products.length !== 0) ? orderData.Products.length : "");
            $("#lBasketTotal").text(orderData.ProductAmount.toFixed(2) + " " + orderData.Currency);
            $("#nBasket").removeClass((orderData.Products.length !== 0) ? "disabled" : "");
            $("#nBasket").addClass((orderData.Products.length === 0) ? "disabled" : "");
        }

        function funcShowBasket(event) {
            event.stopPropagation();
            if ($('#mBasket').find('.dropdown-menu').is(":hidden")) {
                $('#mBasket').find('.dropdown-toggle').dropdown('toggle');
            };
            if ($('#navbar-mobile').is(":hidden")) {
                $('#navbar-mobile').addClass('show');
            };
            csws.Order().LoadOrder();
        }

        function funcCalcProductAmount() {
            orderData.ProductAmount = 0.0;
            for (i = 0; i < orderData.Products.length; i++) {
                orderData.ProductAmount += orderData.Products[i].Price * orderData.Products[i].Quantity;
                orderData.Currency = orderData.Products[i].Currency;
            }
        }

        function funcAddProduct(ID, SupplierID) {
            var prodIndex;
            for (i = 0; i < productsData.length; i++)
                if (productsData[i].ID === ID)
                    prodIndex = i;
            var orderIndex;
            for (i = 0; i < orderData.Products.length; i++)
                if (orderData.Products[i].ID === ID)
                    orderIndex = i;
            if (orderIndex !== undefined) {
                orderData.Products[orderIndex].Quantity += 1;
                orderData.Products[orderIndex].Total = orderData.Products[orderIndex].Price * orderData.Products[orderIndex].Quantity;
            }
            else
            if (prodIndex !== undefined) {
                var oProd = new Object();
                oProd.ID = ID;
                oProd.SupplierID = SupplierID;
                oProd.CodeCat = productsData[prodIndex].CodeCat;
                oProd.Producer = productsData[prodIndex].Producer;
                oProd.Name = productsData[prodIndex].Name;
                oProd.Price = productsData[prodIndex].Price;
                oProd.Currency = productsData[prodIndex].Currency;
                oProd.Quantity = 1;
                oProd.Total = oProd.Price * oProd.Quantity;
                orderData.Products.push(oProd);
            }

            funcCalcProductAmount();
            csws.Cache().UpdateCachedData("orderdata", orderData);
            funcRenderBasket();
        }

        function funcDeleteProduct(ID, SupplierID, atAll) {
            for (i = 0; i < orderData.Products.length; i++)
                if (orderData.Products[i].ID === ID) {
                    if (atAll || orderData.Products[i].Quantity == 1)
                        orderData.Products.splice(i, 1);
                    else {
                        orderData.Products[i].Quantity -= 1;
                        orderData.Products[i].Total = orderData.Products[i].Price * orderData.Products[i].Quantity;
                    }
                    break;
                }
            funcCalcProductAmount();
            csws.Cache().UpdateCachedData("orderdata", orderData);
            funcRenderBasket();
        }

        function funcClearBasket() {
            orderData.DeliveryAmount = 0;
            orderData.ProductAmount = 0;
            orderData.Total = 0;
            orderData.Products = [];
            csws.Cache().UpdateCachedData("orderdata", orderData);
            funcRenderBasket();
        }

        function funcLoadProducts(pData) {
            productsData = pData;
        }

        function funcLoadUserInfo(uData) {
            var needSave = ((orderData.Name != uData.Name) || (orderData.Phone != uData.Phone) || (orderData.Email != uData.Email));
            orderData.Name = uData.Name;
            orderData.Phone = uData.Phone;
            orderData.Email = uData.Email;
            if (needSave) csws.Cache().UpdateCachedData("orderdata", orderData);
        }

        function funcReloadBacketPrices() {
            if (orderData.Products.length <= 0) return;

            var postJson = orderData;
            $.ajax({
                type: "POST",
                url: svcUrl + "cs/basket/refresh",
                dataType: "json",
                data: postJson,
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    orderData = data;
                    funcCalcProductAmount();
                    csws.Cache().UpdateCachedData("orderdata", orderData);
                    funcRenderBasket();
                },
                error: function (data) {
                    funcLogErrors("funcReloadBacketPrices", data);
                }
            });
        }

        function funcInitialization() {
            var ordereData = { ts: 0, Name: "", Phone: "", Email: "", Delivery: "", Currency: '', DeliveryAmount: 0.0, ProductAmount: 0.0, Total: 0.0, Products: [] };
            orderData = csws.Cache().CachedData("orderdata", ordereData);
            if (!csws.Cache().IsDataUpToDate(orderData, 3600000)) { //1 hour
                funcReloadBacketPrices();
            }
            funcRenderBasket();
        }

        return {
            Init: function () { funcInitialization() },
            Add: function (ID, SupplierID) { funcAddProduct(ID, SupplierID) },
            AddEx: function (event, ID, SupplierID) { funcAddProduct(ID, SupplierID); funcShowBasket(event); return false; },
            AddReload: function (ID, SupplierID) { funcAddProduct(ID, SupplierID); csws.Order().LoadOrder(); return false; },
            Subtract: function (ID, SupplierID) { funcDeleteProduct(ID, SupplierID, false) },
            SubtractReload: function (ID, SupplierID) { funcDeleteProduct(ID, SupplierID, false); csws.Order().LoadOrder(); return false; },
            SubtractEx: function (event, ID, SupplierID) { funcDeleteProduct(ID, SupplierID, false); funcShowBasket(event); return false; },
            Delete: function (ID, SupplierID) { funcDeleteProduct(ID, SupplierID, true) },
            Clear: function () { funcClearBasket() },
            Show: function () { funcRenderBasket() },
            LoadProducts: function (pData) { funcLoadProducts(pData); },
            LoadUserInfo: function (uData) { funcLoadUserInfo(uData); },
            ReloadBacketPrices: function () { funcReloadBacketPrices(); },
            OrderData: function () { return orderData; },
        }
    }();

    //  --  CATALOG ----------------
    var _moduleCatalog = function () {

        var brandList;
        var groupList;
        var manufList;
        var selVehicle = 0;
        var navigationID = 0;

        function IsPageLoaded() {
            return ($(".tProducts").length !== 0);
        }

        function funcLoadBrands() {
            brandList = csws.Cache().CachedData("brandlist");
            if (csws.Cache().IsDataUpToDate(brandList)) {
                $('.select-brand').select2({ allowClear: true, data: brandList.list }).select2("val", "0");
                return;
            }
            else
                $('.select-brand').select2({ allowClear: true, data: []});
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/producer",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    brandList.list = $.map(data, function (obj) {
                        obj.id = obj.id || obj.Name;
                        obj.text = obj.text || obj.Name;
                        return obj;
                    });
                    csws.Cache().UpdateCachedData("brandlist", brandList)
                    $('.select-brand').select2({ allowClear: true, data: brandList.list }).select2("val", "0");
                }
            });
        }

        function funcLoadGroups() {
            groupList = csws.Cache().CachedData("grouplist");
            if (csws.Cache().IsDataUpToDate(groupList)) {
                $(".tGroups").DataTable().clear().rows.add(groupList.list).draw();
                return;
            }
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/group",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    groupList.list = data;
                    csws.Cache().UpdateCachedData("grouplist", groupList)
                    $(".tGroups").DataTable().clear().rows.add(groupList.list).draw();
                },
                error: function (data) {
                    funcLogErrors("funcLoadGroups", data);
                }
            });
        }

        function funcLoadGroupDetails(id) {
            funcCatalogNavigation(0);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/group/" + id,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    csws.Basket().LoadProducts(data);
                    $(".tProducts").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    csws.Basket().LoadProducts([]);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadGroupDetails", data);
                }
            });
        }

        function funcProductSearch(keyword, searchtype, brand) {
            funcCatalogNavigation(0);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            var lUrl = svcUrl + "cs/product/search/";
            lUrl += (searchtype != 3) ? keyword.replace(/\W+/g, "") : keyword;
            lUrl += "/" + searchtype
            lUrl += (brand) ? "/" + brand : "";

            $.ajax({
                type: "GET",
                url: lUrl,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    csws.Basket().LoadProducts(data);
                    $(".tProducts").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    csws.Basket().LoadProducts([]);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcProductSearch", data);
                }
            });
        }

        function funcProductSearchEx(event) {
            if (event !== undefined) event.preventDefault();
            var search = new URLSearchParams($("#fSearchEx").serialize());
            funcProductSearch(search.get("keyword"), search.get("searchtype"), search.get("brand"));
        }

        function funcProductSearchTop(event) {
            if (event !== undefined) event.preventDefault();
            document.forms["fSearchEx"]["keyword"].value = document.forms["fSearch"]["keyword"].value;
            funcProductSearchEx(event);
        }

        function funcProductIndo(id) {
            funcCatalogNavigation((navigationID === 1) || (navigationID === 15) ? navigationID : navigationID + 1);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            var lUrl = svcUrl + "cs/product/" + id;

            $.ajax({
                type: "GET",
                url: lUrl,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $(".tReplacements").DataTable().clear().rows.add(data.Replacements).draw();
                    document.forms["fProdDet"]["prodCode"].value = data.CodeCat;
                    document.forms["fProdDet"]["prodBrand"].value = data.Producer;
                    document.forms["fProdDet"]["prodName"].value = data.Name;
                    document.forms["fProdDet"]["prodQuant"].value = data.Quantity;
                    document.forms["fProdDet"]["prodDelivery"].value = funcRenderProductDelivery(data.DeliveryDays, data.Quantity, data.ID);
                    document.forms["fProdDet"]["prodPrice"].value = data.Price.toFixed(2) + " " + data.Currency;
                    document.forms["fProdDet"]["prodDescription"].value = data.Notes; //data.Description;
                    $('#bProdOrder').attr("onClick", funcRenderProductBuy(data.ID, data.SupplierID));
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                    $('#prodImage').attr("src", funcRenderProductImage(data.Image));
                    $('#prodImageLink').attr("href", funcRenderProductImage(data.Image));
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcProductIndo", data);
                }
            });
        }

        function funcLoadManufacturer() {
            funcCatalogNavigation(10);
            manufList = csws.Cache().CachedData("manuflist");
            if (csws.Cache().IsDataUpToDate(manufList)) {
                $("#tManufacture").empty();
                $("#tManufacture").append(funcRenderManufactures(searchUrl, manufList.list));
                return;
            }
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/td/manufacturer",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    manufList.list = data;
                    csws.Cache().UpdateCachedData("manuflist", manufList)
                    $("#tManufacture").empty();
                    $("#tManufacture").append(funcRenderManufactures(searchUrl, manufList.list));
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadProductForVehicle", data);
                }
            });
        }

        function funcLoadModelserie(id) {
            funcCatalogNavigation(11);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/td/modelseries/" + id,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $(".tModelserie").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    funcCatalogNavigation(10);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadProductForVehicle", data);
                }
            });
        }

        function funcLoadVehicle(id) {
            funcCatalogNavigation(12);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/td/vehicles/" + id,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $(".tVehicle").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    funcCatalogNavigation(11);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadProductForVehicle", data);
                }
            });
        }

        function funcLoadAssembly(id) {
            funcCatalogNavigation(13);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            selVehicle = id;
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/td/assembly/" + id,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $('#AssemblyTree').treeview({
                        expandIcon: 'glyphicon icon-folder-plus4',
                        collapseIcon: 'glyphicon icon-folder-minus4',
                        selectedColor: '#333',
                        selectedBackColor: '#E8F5E9',
                        showBorder: false,
                        levels: 1,
                        data: data,
                        onNodeSelected: function (event, node) {
                            funcLoadProductForVehicle(selVehicle, node.ID);
                        }
                    });
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    funcCatalogNavigation(12);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadProductForVehicle", data);
                }
            });
        }

        function funcLoadProductForVehicle(vehicleID, assemblyID) {
            funcCatalogNavigation(14);
            funcPageUpdateProgressInfo(1, "#ipSearch", "#ieSearch", "#isSearch", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/product/td/" + vehicleID + "/" + assemblyID,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    csws.Basket().LoadProducts(data);
                    $(".tProducts").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipSearch", "#ieSearch", "#isSearch", "", null);
                },
                error: function (data) {
                    funcCatalogNavigation(13);
                    csws.Basket().LoadProducts([]);
                    funcPageUpdateProgressInfo(3, "#ipSearch", "#ieSearch", "#isSearch", null, null);
                    funcLogErrors("funcLoadProductForVehicle", data);
                }
            });
        }

        function funcShowTabControl(contriol, visible) {
            $(contriol).addClass(visible ? "active show" : "");
            $(contriol).removeClass(!visible ? "active show" : "");
        }

        function funcCatalogNavigation(mode) {
            navigationID = mode;
            funcShowControl("#lNavHome", (mode === 0));
            funcShowControl("#lNavBack", (mode > 10) || (mode === 1));
            funcShowTabControl("#tProducts", (mode === 0) || (mode === 14));
            funcShowTabControl("#tProductInf", (mode === 1) || (mode === 15));
            funcShowTabControl("#tManufacture", (mode === 10));
            funcShowTabControl("#tModelserie", (mode === 11));
            funcShowTabControl("#tVehicle", (mode === 12));
            funcShowTabControl("#tAssembly", (mode === 13));
            $("#iHeader").text(funcRenderNavigation(mode));
        }

        function funcProcessRequest() {
            var urlParams = new URLSearchParams(window.location.search);
            var pKeyword = urlParams.get('keyword');
            if (pKeyword != null) {
                document.forms["fSearchEx"]["keyword"].value = pKeyword;
                funcProductSearchEx();
                var pid = urlParams.get('id');
                if (pid != null)
                    funcProductIndo(pid);
            }
            if (pKeyword == null)
                funcLoadManufacturer();
        }

        function funcGetIDFromTable(tableName, indexes) {
            var ldata = $(tableName).DataTable().rows(indexes).data();
            return ldata[0].ID;
        }

        function funcInitialization() {
            funcCatalogTablesInitialization(searchUrl);
            $(".tGroups").DataTable().on("select", function (e, dt, type, indexes) {
                if (type === "row")
                    funcLoadGroupDetails(funcGetIDFromTable(".tGroups", indexes));
            });

            $(".tManufacture").DataTable().on("select", function (e, dt, type, indexes) {
                if (type === "row")
                    funcLoadModelserie(funcGetIDFromTable(".tManufacture", indexes));
            });

            $(".tModelserie").DataTable().on("select", function (e, dt, type, indexes) {
                if (type === "row")
                    funcLoadVehicle(funcGetIDFromTable(".tModelserie", indexes));
            });

            $(".tVehicle").DataTable().on("select", function (e, dt, type, indexes) {
                if (type === "row")
                    funcLoadAssembly(funcGetIDFromTable(".tVehicle", indexes));
            });

            if (IsPageLoaded()) funcLoadGroups();
            if (IsPageLoaded()) funcLoadBrands();

            $('.select-type').select2({ minimumResultsForSearch: Infinity });

            if (IsPageLoaded()) funcProcessRequest();
        }

        return {
            Init: function () { funcInitialization() },
            IsPageLoaded: function () { return IsPageLoaded() },
            DoSearchTop: function (event) { funcProductSearchTop(event); },
            DoSearchEx: function (event) { funcProductSearchEx(event); },
            DoLoadProduct: function (id) { funcProductIndo(id); },
            DoLoadModelserie: function (id) { funcLoadModelserie(id); return false; },
            DoNavigateHome: function (event) { funcLoadManufacturer(); funcCatalogNavigation(10); return false; },
            DoNavigateBack: function (event) { funcCatalogNavigation(navigationID - 1); return false; }
        }
    }();

    //  --  ORDER ------------------
    var _moduleOrder = function () {

        var deliveryList;

        function IsPageLoaded() {
            return ($("#fOrder").length !== 0);
        }

        function funcLoadOrderData() {
            if (!IsPageLoaded()) return;
            var oData = csws.Basket().OrderData();
            $(".tOrderProducts").DataTable().clear().rows.add(oData.Products).draw();
            $("#iOrderQuantity").val(oData.Products.length);
            funcShowOrderTotal();
        }

        function funcUpdateDeliveryAmount() {
            var selectData = $('.select-delivery').select2('data');
            var needSave = ((selectData.length > 0) && (csws.Basket().OrderData().Delivery != selectData[0].id));
            csws.Basket().OrderData().DeliveryAmount = (selectData.length > 0) ? selectData[0].Amount : 0.00;
            csws.Basket().OrderData().Delivery = (selectData.length > 0) ? selectData[0].id : null;
            if (needSave) csws.Cache().UpdateCachedData("orderdata", csws.Basket().OrderData());
            funcShowOrderTotal();
        }

        function funcShowOrderTotal() {
            var oData = csws.Basket().OrderData();
            var orderSumm = oData.ProductAmount + oData.DeliveryAmount;
            $("#iOrderTotal").val(orderSumm.toFixed(2));
        }

        function funcShowOrderUser() {
            if (!IsPageLoaded()) return;
            var oData = csws.Basket().OrderData();
            $("#iOrderName").val((oData !== null) ? oData.Name : "");
            $("#iOrderPhone").val((oData !== null) ? oData.Phone : "");
            $("#iOrderEmail").val((oData !== null) ? oData.Email : "");
        }

        function funcUpdateDeliveryControl(data, value) {
            var list = $.map(data, function (obj) {
                obj.id = obj.id || obj.ID;
                obj.text = obj.text || obj.Name;
                return obj;
            });
            $('.select-delivery').select2({ minimumResultsForSearch: Infinity, data: list });
            $('.select-delivery').val(value).trigger('change');
        }

        function funcLoadDelivery() {
            deliveryList = csws.Cache().CachedData("deliverylist");
            if (csws.Cache().IsDataUpToDate(deliveryList, 1000)) { // issue with amount refresh
                funcUpdateDeliveryControl(deliveryList.list, csws.Basket().OrderData().Delivery);
                return;
            }
            else
                $('.select-delivery').select2({ minimumResultsForSearch: Infinity, data: [] });

            $.ajax({
                type: "GET",
                url: svcUrl + "cs/delivery",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    deliveryList.list = data;
                    csws.Cache().UpdateCachedData("deliverylist", deliveryList)
                    funcUpdateDeliveryControl(deliveryList.list, csws.Basket().OrderData().Delivery);
                    funcUpdateDeliveryAmount();
                }
            });
        }

        function funcProcessOrder(event) {
            if (event !== undefined) event.preventDefault();
            funcPageUpdateProgressInfo(1, "#ipOrder", "#ieOrder", "#isOrder", "", null);
            var formData = new URLSearchParams($("#fOrder").serialize());
            postData = new Object();
            postData.Name = formData.get("Name");
            postData.Phone = formData.get("Phone");
            postData.Email = formData.get("Email");
            postData.Delivery = formData.get("Delivery");
            postData.Address = formData.get("Address");
            postData.Notes = formData.get("Notes");
            postData.Products = csws.Basket().OrderData().Products;
            postJson = postData;

            $.ajax({
                type: "POST",
                url: svcUrl + "cs/order",
                dataType: "json",
                data: postJson,
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    funcPageUpdateProgressInfo(2, "#ipOrder", "#ieOrder", "#isOrder", "Заказ успешно создан", null);
                    csws.Basket().Clear();
                    funcLoadOrderData();
                    $("#modalMessage").modal("show");
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipOrder", "#ieOrder", "#isOrder", null, data);
                    funcLogErrors("funcProcessOrder", data);
                }
            });
        }

        function funcOrderNavigation(event) {
            if (event !== undefined) event.preventDefault();
            window.location.replace((csws.User().IsLogedIn()) ? "/history.php" : "/index.php");
        }

        function funcPayOrder(ID, RecType) {
            funcShowInformationMessage("Not implemented yet");
        }

        function funcInitialization() {
            funcOrderTablesInitialization(searchUrl);

            if (IsPageLoaded()) funcLoadDelivery();
            if (IsPageLoaded()) funcLoadOrderData();
            if (IsPageLoaded()) funcShowOrderUser();

            $('.select-delivery').select2().on("select2:select", function (e) { funcUpdateDeliveryAmount(); });
            $('.select-delivery').select2({ minimumResultsForSearch: Infinity });
        }

        return {
            Init: function () { funcInitialization() },
            IsPageLoaded: function () { return IsPageLoaded() },
            LoadOrder: function () { funcLoadOrderData() },
            ProcessOrder: function (event) { funcProcessOrder(event) },
            OrderNavigation: function (event) { funcOrderNavigation(event) },
            PaymentForOrder: function (ID, RecType) { funcPayOrder(ID, RecType) },
        }
    }();


    //  --  USER REGISTRATION -----------
    var _moduleRegistration = function () {

        function IsPageLoaded() {
            return ($("#fRegistration").length !== 0);
        }

        function funcUserRegistration(event) {
            if (event !== undefined) event.preventDefault();
            document.forms["flogin"]["username"].value = document.forms["fregistration"]["Email"].value;
            document.forms["flogin"]["password"].value = document.forms["fregistration"]["Password"].value;
            funcPageUpdateProgressInfo(1, null, null, "#isRegistration", "", null);

            var formData = $("#fRegistration").serialize();
            $.ajax({
                type: "POST",
                url: svcUrl + "cs/registration",
                dataType: "json",
                data: formData,
                success: function (data) {
                    funcPageUpdateProgressInfo(2, null, null, "#isRegistration", "Регистрация прошла успешно", null);
                    csws.User().Login();
                },
                error: function (data) {
                    document.forms["flogin"]["password"].value = "";
                    funcPageUpdateProgressInfo(3, null, null, "#isRegistration", null, data);
                    funcLogErrors("funcUserRegistration", data);
                }
            });
        }

        function funcInitialization() {
        }

        return {
            Init: function () { funcInitialization() },
            IsPageLoaded: function () { return IsPageLoaded() },
            DoRegistration: function (event) { funcUserRegistration(event) }
        }
    }();

    //  --  USER PROFILE -----------
    var _moduleProfile = function () {

        var countryList;

        function IsPageLoaded() {
            return ($("#fProfile").length !== 0);
        }

        function funcLoadCountries() {
            countryList = csws.Cache().CachedData("countrylist");
            if (csws.Cache().IsDataUpToDate(countryList)) {
                $('.select-country').select2({ minimumResultsForSearch: Infinity, data: countryList.list });
                return;
            }
            else
                $('.select-country').select2({ minimumResultsForSearch: Infinity, data: [] });
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/country",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    countryList.list = $.map(data, function (obj) {
                        obj.id = obj.id || obj.Name;
                        obj.text = obj.text || obj.Name;
                        return obj;
                    });
                    csws.Cache().UpdateCachedData("countrylist", countryList)
                    $('.select-country').select2({ minimumResultsForSearch: Infinity, data: countryList.list });
                }
            });
        }

        function funcLoadProfile() {
            funcPageUpdateProgressInfo(1, "#ipProfile", "#ieProfile", "#isProfile", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/userdata",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    document.forms["fProfile"]["Name"].value = data.Name;
                    document.forms["fProfile"]["ContactPerson"].value = data.ContactPerson;
                    document.forms["fProfile"]["Phone1"].value = data.Phone1;
                    document.forms["fProfile"]["Phone2"].value = data.Phone2;
                    document.forms["fProfile"]["Email"].value = data.Email;
                    document.forms["fProfile"]["WebSite"].value = data.WebSite;
                    document.forms["fProfile"]["Region"].value = data.Region;
                    document.forms["fProfile"]["City"].value = data.City;
                    document.forms["fProfile"]["ZIP"].value = data.ZIP;
                    document.forms["fProfile"]["Address1"].value = data.Address1;
                    $('.select-country').val(data.Country).trigger('change');
                    funcPageUpdateProgressInfo(2, "#ipProfile", "#ieProfile", "#isProfile", "", null);
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipProfile", "#ieProfile", "#isProfile", null, data);
                    if (data.status === 401) return csws.User().ShowInfo(null, true);
                    funcLogErrors("funcLoadProfile", data);
                }
            });
        }

        function funcUpdateProfile(event) {
            if (event !== undefined) event.preventDefault();
            funcPageUpdateProgressInfo(1, "#ipProfile", "#ieProfile", "#isProfile", "", null);
            var formData = $("#fProfile").serialize();
            $.ajax({
                type: "POST",
                url: svcUrl + "cs/updateprofile",
                dataType: "json",
                data: formData,
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    funcPageUpdateProgressInfo(2, "#ipProfile", "#ieProfile", "#isProfile", "Данные успешно сохранены", null);
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipProfile", "#ieProfile", "#isProfile", null, data);
                    if (data.status === 401) return csws.User().ShowInfo(null, true);
                    funcLogErrors("funcUpdateProfile", data);
                }
            });
        }

        function funcChangePassword(event) {
            if (event !== undefined) event.preventDefault();
            funcPageUpdateProgressInfo(1, "#ipPassword", "#iePassword", "#isPassword", "", null);
            var formData = $("#fPassword").serialize();
            $.ajax({
                type: "POST",
                url: svcUrl + "cs/changepassword",
                dataType: "json",
                data: formData,
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    funcPageUpdateProgressInfo(2, "#ipPassword", "#iePassword", "#isPassword", "Пароль успешно изменен", null);
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipPassword", "#iePassword", "#isPassword", null, data);
                    if (data.status === 401) return csws.User().ShowInfo(null, true);
                    funcLogErrors("funcChangePassword", data);
                }
            });
        }

        function iconFormat(icon) {
            var originalOption = icon.element;
            if (!icon.id) { return icon.text; }
            var $icon = '<i class="icon-' + $(icon.element).data('icon') + '"></i>' + icon.text;
            return $icon;
        }

        function funcInitialization() {
            if (IsPageLoaded()) funcLoadCountries();
            if (IsPageLoaded()) funcLoadProfile();

            $('.select-icons').select2({
                templateResult: iconFormat,
                minimumResultsForSearch: Infinity,
                templateSelection: iconFormat,
                escapeMarkup: function (m) { return m; }
            });
        }

        return {
            Init: function () { funcInitialization() },
            IsPageLoaded: function () { return IsPageLoaded() },
            Load: function () { funcLoadProfile() },
            Update: function (event) { funcUpdateProfile(event); },
            ChangePassword: function (event) { funcChangePassword(event); },
            UpdateBalance: function (event) { event.preventDefault(); }  // Not Implemented yet
        }
    }();


    //  --  ORDER HISTORY ---------------
    var _moduleOrderHistory = function () {

        function IsPageLoaded() {
            return ($(".tHistoryOrder").length !== 0);
        }

        function funcLoadOrders() {
            funcPageUpdateProgressInfo(1, "#ipOrders", "#ieOrders", "#isOrders", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/history",
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $(".tHistoryOrder").DataTable().clear().rows.add(data).draw();
                    funcPageUpdateProgressInfo(2, "#ipOrders", "#ieOrders", "#isOrders", "", null);
                    $(".tHistoryOrder").DataTable().row(":eq(0)").select();
                },
                error: function (data) {
                    $(".tHistoryOrder").DataTable().clear().draw();
                    funcPageUpdateProgressInfo(3, "#ipOrders", "#ieOrders", "#isOrders", null, null);
                    if (data.status === 401) return csws.User().ShowInfo(null, true);
                    funcLogErrors("funcLoadOrders", data);
                }
            });
        }

        function funcLoadDetails(id, oType) {
            funcPageUpdateProgressInfo(1, "#ipOrderProducts", "#ieOrderProducts", "#isOrderProducts", "", null);
            funcPageUpdateProgressInfo(1, "#ipOrderWorks", "#ieOrderWorks", "#isOrderWorks", "", null);
            $.ajax({
                type: "GET",
                url: svcUrl + "cs/history/" + id + "/" + oType,
                dataType: "json",
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    $(".tHistoryProducts").DataTable().clear().rows.add(data.Products).draw();
                    $(".tHistoryWorks").DataTable().clear().rows.add(data.Works).draw();
                    funcPageUpdateProgressInfo(2, "#ipOrderProducts", "#ieOrderProducts", "#isOrderProducts", "", null);
                    funcPageUpdateProgressInfo(2, "#ipOrderWorks", "#ieOrderWorks", "#isOrderWorks", "", null);
                },
                error: function (data) {
                    $(".tHistoryProducts").DataTable().clear().draw();
                    $(".tHistoryWorks").DataTable().clear().draw();
                    funcPageUpdateProgressInfo(3, "#ipOrderProducts", "#ieOrderProducts", "#isOrderProducts", null, null);
                    funcPageUpdateProgressInfo(3, "#ipOrderWorks", "#ieOrderWorks", "#isOrderWorks", "", null);
                    if (data.status === 401) return csws.User().ShowInfo(null, true);
                    funcLogErrors("funcLoadDetails", data);
                }
            });
        }

        function funcInitialization() {
            if (IsPageLoaded()) funcLoadOrders();
            funcOrderHistoryTablesInitialization(searchUrl);

            $(".tHistoryOrder").DataTable().on("select", function (e, dt, type, indexes) {
                if (type === "row") {
                    var ldata = $(".tHistoryOrder").DataTable().rows(indexes).data();
                    funcLoadDetails(ldata[0].ID, ldata[0].RecType);
                }
            });
        }

        return {
            Init: function () { funcInitialization() },
            IsPageLoaded: function () { return IsPageLoaded() },
            Load: function () { funcLoadOrders() },
            LoadDetails: function (id, oType) { funcLoadDetails(id, oType) }
        }
    }();


    //  --  REQUEST ------------------
    var _moduleRequest = function () {

        function IsPageLoaded() {
            return ($("#fRequest").length !== 0);
        }

        function funcShowRequestUser() {
            if (!IsPageLoaded()) return;
            var uData = csws.User().UserData();
            $("#iRequestName").val((uData !== undefined) ? uData.Name : "");
            $("#iRequestPhone").val((uData !== undefined) ? uData.Phone : "");
            $("#iRequestEmail").val((uData !== undefined) ? uData.Email : "");
        }

        function funcProcessRequest(event) {
            if (event !== undefined) event.preventDefault();
            funcPageUpdateProgressInfo(1, "#ipRequest", "#ieRequest", "#isRequest", "", null);
            var formData =$("#fRequest").serialize();
            //var formData = new URLSearchParams($("#fRequest").serialize());

            $.ajax({
                type: "POST",
                url: svcUrl + "cs/vinrequest",
                dataType: "json",
                data: formData,
                beforeSend: function (xhr) { xhr.setRequestHeader(svcAuthorization, csws.Cache().ReqToken()); },
                success: function (data) {
                    funcPageUpdateProgressInfo(2, "#ipRequest", "#ieRequest", "#isRequest", "Запрос успешно отправлен", null);
                    $("#modalMessage").modal("show");
                },
                error: function (data) {
                    funcPageUpdateProgressInfo(3, "#ipRequest", "#ieRequest", "#isRequest", null, data);
                    funcLogErrors("funcProcessRequest", data);
                }
            });
        }

        function funcRequestNavigation(event) {
            if (event !== undefined) event.preventDefault();
            window.location.replace((csws.User().IsLogedIn()) ? "/index.php" : "/index.php");
        }

        function funcInitialization() {
            if (IsPageLoaded()) funcShowRequestUser();
        }

        return {
            Init: function () { funcInitialization() },
            ProcessRequest: function (event) { funcProcessRequest(event) },
            RequestNavigation: function (event) { funcRequestNavigation(event) },
        }
    }();

    //  --  Check loaded components -
    var _appinit = function () {
        if (!$().DataTable) {
            console.warn('Warning - datatables.min.js is not loaded.');
            return;
        }
        if (!$().select2) {
            console.warn('Warning - select2.min.js is not loaded.');
            return;
        }

        $.extend($.fn.dataTable.defaults, {
            autoWidth: false,
            responsive: true,
            searching: false,
            paging: true,
            pageLength: 10,
            select: {
                style: "single"
            },
            columnDefs: [{
                orderable: false,
                width: 100
            }],
            dom: '<"datatable-scroll-wrap"t><"datatable-footer paginate-right"fp>',
            lengthMenu: [
                [10, 25, 50, -1],
                ['10 rows', '25 rows', '50 rows', 'Show all']
            ],
            buttons: [
                {
                    extend: 'pageLength',
                    className: 'btn bg-slate-600'
                }
            ],
            language: {
                //url: "scripts/plugins/datatables.russian.lang.js"
                search: "",
                searchPlaceholder: "Введите фразу для поиска...",
                processing: "Подождите...",
                loadingRecords: "Загрузка записей...",
                zeroRecords: "Нет данных для отображения",
                emptyTable: "",
                paginate: { first: "Первая", previous: "&larr;", next: "&rarr;", last: "Последняя" }
            }
        });

    };

    return {
        Cache: function () { return _moduleCache; },
        User: function () { return _moduleUser; },
        Basket: function () { return _moduleBasket; },
        Order: function () { return _moduleOrder; },
        Catalog: function () { return _moduleCatalog; },
        Profile: function () { return _moduleProfile; },
        Registration: function () { return _moduleRegistration; },
        OrderHistory: function () { return _moduleOrderHistory; },
        Request: function () { return _moduleRequest; },
        Init: function () {
            _appinit();
            _moduleCache.Init();
            _moduleUser.Init();
            _moduleBasket.Init();
            _moduleOrder.Init();
            _moduleCatalog.Init();
            _moduleProfile.Init();
            _moduleRegistration.Init();
            _moduleOrderHistory.Init();
            _moduleRequest.Init();
        }
    };
}();


// Initialize module
// ------------------------------

document.addEventListener('DOMContentLoaded', function() {
    csws.Init();
});
